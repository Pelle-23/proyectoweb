<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
</head>
<body>
	<nav>
		<ul>
			<li class="nav"><a href="index.php"><i class="fas fa-house-user"></i>Inicio</a></li>
			<li class="nav"><a href="celulares.php"><i class="fas fa-mobile-alt"></i>Dispositivos</a></li>
			<li class="nav"><a href="destacado.php"><i class="far fa-star"></i>Favoritos</a></li>
			<li class="nav"><a href="comparativa.php"><i class="fas fa-balance-scale"></i>Comparativa</a></li>
			<li class="nav"><a href="contacto.php"><i class="far fa-envelope"></i></i>Contacto</a></li>
		</ul>
	</nav>
</body>
</html>