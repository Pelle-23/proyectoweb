<html>
<head>
	<title>Comparar celulares, especificaciones tecnicas</title>
	<link rel="stylesheet" type="text/css" href="estilos.css">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>
<body>
<?php
	include("modulos/encabezado.php");
	include("modulos/busqueda.php");
	include("modulos/menu.php");
	include("modulos/contacto.php");
?>
<form action="" method="get">
	<label for="disp1">Dispositivo</label>
	<input type="text" placeholder="Ej: xiaomi pocophonef1" id="disp1">
	<label for="disp2">Dispositivo</label>
	<input type="text" placeholder="Ej: xiaomi pocophonef1" id="disp2">
	<input type="submit" value="Comparar">
</form>
</body>
</html>