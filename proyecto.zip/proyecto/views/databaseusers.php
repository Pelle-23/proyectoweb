<?php
	$server = 'localhost';
	$username = 'root';
	$password = '';
	$database = 'registro_usuarios';
	$enlace = mysqli_connect($server,$username,$password,$database);
	if($enlace==false){
		die("Fallo la conexión a la base de datos".$enlace->connect_error());
	}
?>