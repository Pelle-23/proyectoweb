<?php
require 'databaseusers.php';

?>
<!DOCTYPE html>
<html>
<head>
	<title>Encabezado</title>
	<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
	<header>
		<div class="buscar">
			<img class="logo" src="imagenes/logotipo.jpg">
			<form action="" method="get">
			<input class="busqueda" type="text" placeholder="Buscar dispositivo...">
			<button class="enviar" type="submit"><span class="fas fa-search"></span></button>
			</form>
		</div>
		<?php
			#$consulta = "SELECT user FROM registro ";
			#$user=mysqli_query($enlace,$consulta);
			#$fila=mysqli_fetch_array($user);
##################################################################################################
			#SE DESPLIEGA CERRAR SESIÓN
#################################################################################################
			 #echo $fila['user'];
			 ##else{
			#}
			#?>	 
			 <a class="usuario" href="users.php"><i class="fas fa-user"></i>Usuario</a>
			 <a class="logout" href="logout.php">Cerrar sessión</a>
	</header>
</body>
</html>
