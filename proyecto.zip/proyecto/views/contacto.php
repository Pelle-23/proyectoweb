<!DOCTYPE html>
<html>
<head>
	<title>Exxylon, características de celulares</title>
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<meta charset="utf8">
</head>
<body>
	<header>
		<?php
			include("modulosindex/encabezado.php");
		?>
	</header>
	<article>
		<?php
			include("modulosindex/navcuerpo.php");
		?>
		<section>
			<ul>
				<li><a href="">(ig.icono) exxylon_</a></li>
				<li>(correo.icono)exxylonsite@gmail.com</li>
				<li><a href="" target="_BLANK">(facebook.icono)exxylon</a></li>
			</ul>
		</section>
	</article>
</body>
</html>
