<?php
	require_once 'databaseusers.php';

	$message='';

	if(!empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['password']) && !empty($_POST['confirm_password'])){
		$nombre = $_POST['name'];
		$mail = $_POST['email'];
		if($_POST['password'] == $_POST['confirm_password']){
			$password = password_hash($_POST['password'], PASSWORD_BCRYPT);
			$consulta = "INSERT INTO registro (user,email,password) VALUES ('".$nombre."','".$mail."','".$password."')";
			$resultado = mysqli_query($enlace,$consulta);
			if($resultado){
				$messaje='Usuario creado correctamente';
			}
			else{
				$messaje='Error al crearse';
			}
		}else{ 
			echo 'Las contrasañas no coinciden';
		}
		
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Registrarse</title>
</head>
<body>

	<h1>Registro de usuario</h1>
	<?php
	if(!empty($messaje))
	{
		header("location: login.php");
	}
	?>
	<span>o <a href="login.php">Logearse</a></span>
	<form action="registrarse.php" method="post">
		<input type="text" name="name" placeholder="Elegir nombre de usuario">
		<input type="email" name="email" placeholder="Elegir mail">
		<input type="password" name="password" placeholder="Elegir contraseña">
		<input type="password" name="confirm_password" placeholder="Confirmar contraseña">
		<input type="submit" value="Send">
	</form>
	<a href="portada.php">Inicio</a>
</body>
</html>