<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="estilos.css">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>
<body>
<?php
	include("modulos/encabezado.php");
	include("modulos/busqueda.php");
	include("modulos/menu.php");
	include("modulos/contacto.php");
?>
Hay que ver como enlazar los añadidos a favoritos de la tabla de dispositivos de la base de datos aca
</body>
</html>
	


