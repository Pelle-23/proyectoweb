<?php
	session_start();

	#Destruye variables de sessión, destruye sessión y redirige al inicio de sessión

	$_SESSION = array();
	session_destroy();
	header("location: login.php");
	exit;
?>