<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset = "utf-8">
	<title>Recomendación de celulares</title>
	<meta name="descriptipon" content="Caracteristicas y especificaciones de celulares, recomendar celulares">
	<meta name="author" content="Exxylon">
	<meta name="keyboards" content="Iphone, Samsung Galaxy, Xiaomi">
	<link rel="stylesheet" type="text/css" href="estilos.css">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>
<body>	
	<?php
		include("modulosindex/encabezado.php");
		include("modulosindex/menu.php");
	?>
	
</body>
</html>
	