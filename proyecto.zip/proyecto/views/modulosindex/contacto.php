<!DOCTYPE html>
<html>
<head>
	<title>Exxylon, características de celulares</title>
</head>
<body>
	<aside>
	<ul>
		<li><a href="">(ig.icono) exxylon_</a></li>
		<li>(correo.icono)exxylon@gmail.com</li>
		<li><a href="">(facebook.icono)exxylon</a></li>
	</ul>
</aside>
</body>
</html>
