<!DOCTYPE html>
<html>
<head>
	<title>Celulares Xiaomi, Samsung, Iphone, Huawei</title>
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>
<body>
	<?php
	include ("modulosindex/encabezado.php");
	include ("modulosindex/menu.php");
	?>
	<section>
		<ul>
			<li><a href=""><img></a></li>
			<li><a href=""><img></a></li>
			<li><a href=""><img></a></li>
			<li><a href=""><img></a></li>
			<li><a href=""><img></a></li>
		</ul>
	</section>
</body>
</html>