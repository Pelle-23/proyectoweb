<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Recomendación de celulares</title>
	<meta name="descriptipon" content="Caracteristicas y especificaciones de celulares, recomendar celulares">
	<meta name="author" content="Exxylon">
	<meta name="keyboards" content="Iphone, Samsung Galaxy, Xiaomi">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>
<body>	
	<header>
		<?php
			include("modulosindex/encabezado.php");
		?>
	</header>
	<article>
		<?php
		include("modulosindex/navcuerpo.php");
		?>
	</article>
</body>
</html>
	