<?php
session_start();
if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true){
	header("location: index.php");
	exit;
}
require_once 'databaseusers.php';
if($_SERVER["REQUEST_METHOD"] == "POST"){
	if(empty(trim($_POST['email']))){
		 echo $email_err = "Ingrese el correo electrónico";
	}
	else{
		$email = trim($_POST['email']); 
	}
	if(empty(trim($_POST['password']))){
		 echo $password_err = "Ingrese a contraseña";
	}
	else{
		 $password = trim($_POST['password']);
	}
	if(empty($email_err) && empty($password_err)){
		$consulta = "SELECT id, email, password FROM registro WHERE email = ?";
		if($stmt = mysqli_prepare($enlace,$consulta)){
			mysqli_stmt_bind_param($stmt,"s",$param_email);
			$param_email = $email;
			if(mysqli_stmt_execute($stmt)){
				mysqli_stmt_store_result($stmt);
				if(mysqli_stmt_num_rows($stmt)==true){
					mysqli_stmt_bind_result($stmt, $id, $email, $hashed_password);
					if(mysqli_stmt_fetch($stmt)){
						if(password_verify($password, $hashed_password)){
							session_start();
							$_SESSION['loggedin'] = true;
							$_SESSION['id'] = $id;
							$_SESSION['email'] = $email;
							header("location: index.php");
						}else{
							echo $password_err = "La contraseña ingresada no es válida";
						}
					}
				}else{
					echo $email_err = "El email es incorrecto";
				}
			}else{
				echo "Algo salió mal vuelve a intentarlo";
			}
		}
		mysqli_stmt_close($stmt);
		}
	mysqli_close($enlace);
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="estilos.css">
</head>
<body>
	<h1 class="one">Inicicar Sesión</h1>
	<span>o <a class="link" href="registrarse.php">Registrarse</a></span>
	<form action="login.php" method="post">
		<input class="caja" type="email" name="email" placeholder="Ingresa tu mail" autocomplete="off">
		<input class="caja" type="password" name="password" placeholder="Ingresa tu contraseña" autocomplete="off">
		<input class="boton" type="submit" value="Enviar">
	</form>
	<a href="index.php">Inicio</a>
</body>
</html>