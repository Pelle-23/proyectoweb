<!DOCTYPE html>
<html>
<head>
	<title>Celulares Xiaomi, Samsung, Iphone</title>
</head>
<body>
	<?php
	include ("modulos/encabezado.php");
	include ("modulos/busqueda.php");
	include ("modulos/menu.php");
	include ("modulos/contacto.php");
	?>
</body>
</html>