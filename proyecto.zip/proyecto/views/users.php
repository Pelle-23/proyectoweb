<!DOCTYPE html>
<html>
<head>
	<title>Registro y inicio de sesion de usuarios</title>
</head>
<body>
	<a href="login.php" class="logearse">Logearse</a> o
	<a href="registrarse.php">Registrarse</a>
</body>
</html>