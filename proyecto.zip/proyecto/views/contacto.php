<!DOCTYPE html>
<html>
<head>
	<title>Exxylon, características de celulares</title>
	<link rel="stylesheet" type="text/css" href="styles.css">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>
<body>
	<!--<aside>
	<ul>
		<li><a href="">(ig.icono) exxylon_</a></li>
		<li>(correo.icono)exxylonsite@gmail.com</li>
		<li><a href="">(facebook.icono)exxylon</a></li>
	</ul>
</aside>
-->
</body>
</html>
