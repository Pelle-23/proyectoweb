<!DOCTYPE html>
<html>
<head>
	<title>Celulares Xiaomi, Samsung, Iphone, Huawei</title>
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<meta charset="utf-8">
</head>
<body>
	<header>
		<?php
			include ("modulosindex/encabezado.php");
		?>
	</header>
	<article>
		<?php
			include ("modulosindex/navcuerpo.php");
		?>
		<section>
			
		</section>
	</article>
</body>
</html>