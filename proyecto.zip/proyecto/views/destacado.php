<!DOCTYPE html>
<html>
<head>
	<title>Celulares destacados</title>
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<meta charset="utf-8">
</head>
<body>
	<header>
		<?php
			include("modulosindex/encabezado.php");
			
		?>
	</header>
	<article>
		<?php
			include("modulosindex/navcuerpo.php");
		?>
		<!--Hay que ver como enlazar los añadidos a favoritos de la tabla de dispositivos de la base de datos aca-->
	</article>
</body>
</html>
	


