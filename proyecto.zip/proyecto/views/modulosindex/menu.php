<!DOCTYPE html>
<html>
<head>
	<title>Celulares, comparación y favoritos</title>
	<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
<div class="panel">
<aside>
	<ul>
		
		<li class="nav"><a class="visit" href="index.php"><i class="fas fa-house-user"></i>Inicio</a></li>
		<li class="nav"><a class="visit" href="celulares.php"><i class="fas fa-mobile-alt"></i>Dispositivos</a></li>
		<li class="nav"><a class="visit" href="destacado.php"><i class="far fa-star"></i>Favoritos</a></li>
		<li class="nav"><a class="visit" href="comparativa.php"><i class="fas fa-balance-scale"></i>Comparativa</a></li>
		<li class="nav"><a class="visit" href="contacto.php"><i class="far fa-envelope"></i></i>Contacto</a></li>
	</ul>
</aside>
</body>
</html>
