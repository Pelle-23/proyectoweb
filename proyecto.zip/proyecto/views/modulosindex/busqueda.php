<!DOCTYPE html>
<html>
<head>
	<title>Busqueda de celulares Samsung, iphone</title>
</head>
<body>
<form action="" method="get">
	<input type="text" placeholder="Buscar dispositivo">
	<input type="submit" value="Buscar">
</form>
</body>
</html>

