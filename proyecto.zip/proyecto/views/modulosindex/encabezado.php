<?php
require 'databaseusers.php';

?>
<!DOCTYPE html>
<html>
<head>
	<title>Encabezado</title>
	<link rel="stylesheet" type="text/css" href="estilos.css">
</head>
<body>
	<header>
		<h1>Logo(Hacer Joni)</h1>
		<?php
			$consulta = "SELECT user FROM registro ";
			$user=mysqli_query($enlace,$consulta);
			$fila=mysqli_fetch_array($user);
	#################################################################################################
			#SE DESPLIEGA CERRAR SESIÓN
	#################################################################################################
			 echo $fila['user'];
			
			 #else{
				#echo "<a href='users.php'>USUARIO</a>";
			#}
			?>		 
	</header>
</body>
</html>
