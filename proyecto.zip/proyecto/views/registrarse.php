<?php
	require_once 'databaseusers.php';

	$message='';

	if(!empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['password']) && !empty($_POST['confirm_password'])){
		$nombre = $_POST['name'];
		$mail = $_POST['email'];
		$result = mysqli_query($enlace,"SELECT email FROM registro WHERE email = '$mail'");
		$validacion=mysqli_fetch_array($result);
		if($validacion['email']!=$mail){
			if($_POST['password'] == $_POST['confirm_password']){
				$password = password_hash($_POST['password'], PASSWORD_BCRYPT);
				$consulta = "INSERT INTO registro (user,email,password) VALUES ('".$nombre."','".$mail."','".$password."')";
				$resultado = mysqli_query($enlace,$consulta);
				if($resultado){
					$messaje='Usuario creado correctamente';
				}
				else{
					$messaje='Error al crearse';
				}
			}else{ 
				echo 'Las contrasañas no coinciden';
			}
		}else{
			echo 'El email ingresado ya existe';
		}
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Registrarse</title>
	<link rel="stylesheet" type="text/css" href="estilos.css">
</head>
<body>

	<h1>Registro de usuario</h1>
	<?php
	if(!empty($messaje))
	{
		header("location: login.php");
	}
	?>
	<span>o <a class="link" href="login.php">Logearse</a></span>
	<form action="registrarse.php" method="post">
		<input class="caja" type="text" name="name" placeholder="Elegir nombre de usuario" autocomplete="off">
		<input class="caja" type="email" name="email" placeholder="Elegir mail" autocomplete="off">
		<input class="caja" type="password" name="password" placeholder="Elegir contraseña" minlength="7" maxlength="20" autocomplete="off">
		<input class="caja" type="password" name="confirm_password" placeholder="Confirmar contraseña" minlength="7" maxlength="20" autocomplete="off">
		<input class="boton" type="submit" value="Enviar">
	</form>
	<a href="index.php">Inicio</a>
</body>
</html>