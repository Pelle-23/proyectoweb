<!DOCTYPE html>
<html>
<head>
	<title>Celulares, comparación y favoritos</title>
</head>
<body>
<div class="panel">
<aside>
	<ul>
		
			<li><a href="portada.php"><i class="fas fa-house-user"></i>Inicio</a></li>
			<li><a href="celulares.php">Celulares</a></li>
			<li><a href="destacado.php">Destacado</a></li>
			<li><a href="comparativa.php"><i class="fas fa-balance-scale"></i>Comparativa</a></li>
		
	</ul>
</aside>
</body>
</html>
