<?php
require 'databaseusers.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
</head>
<body>
	<img src="imagenes/logotipo.jpg">
	<nav>
		<form action="" method="get">
			<input type="text" placeholder="Buscar dispositivo...">
			<button type="submit"><span class="fas fa-search"></span></button>
		</form>
		<!--<?php
			#$consulta = "SELECT user FROM registro ";
			#$user=mysqli_query($enlace,$consulta);
			#$fila=mysqli_fetch_array($user);
##################################################################################################
			#SE DESPLIEGA CERRAR SESIÓN
#################################################################################################
			 #echo $fila['user'];
			 ##else{
			#}
			#?>	-->
		<a href="users.php"><i class="fas fa-user"></i>Usuario</a>
		<a href="logout.php">Cerrar sessión</a>
	</nav>
</body>
</html>
